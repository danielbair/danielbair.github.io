#!/bin/bash

xmlInsert="\    <layout>\n      <configItem>\n        <name>ksw</name>\n        <shortDescription>ksw</shortDescription>\n        <description>Sgaw Karen</description>\n        <languageList>\n          <iso639Id>ksw</iso639Id>\n        </languageList>\n      </configItem>\n      <variantList/>\n    </layout>\n    <layout>\n      <configItem>\n        <name>pwo</name>\n        <shortDescription>pwo</shortDescription>\n        <description>Western Pwo Karen</description>\n        <languageList>\n          <iso639Id>pwo</iso639Id>\n        </languageList>\n      </configItem>\n      <variantList/>\n    </layout>"
lstInsert=" ksw             Sgaw Karen\n  pwo             Western Pwo Karen"

sed -i.bak "/! layout/a \ $lstInsert" /usr/share/X11/xkb/rules/*.lst
sed -i.bak "/  <layoutList>/a \ $xmlInsert" /usr/share/X11/xkb/rules/*xml

cp ./{ksw,pwo} /usr/share/X11/xkb/symbols/
